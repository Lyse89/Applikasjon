  <div class="navHeader">
    <div class="headerNav" id="headerNav">
      <img class="logo-headerNav" src="img/logo.png" alt="Logoen til USN" width="84" height="42">
        <div class="Loggin">
          <input type="text" placeholder="Brukernavn" id="navn">
          <input type="text" placeholder="Passord" id="pw">
          <button type="submit">Login</button>
        </div>
    </div>
  </div>

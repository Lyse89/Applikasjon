<!-- Denne include-siden er utviklet av Simen A. Lyse , siste gang endret 14.12.2018
// Denne include-siden er kontrollert av Simen A. Lyse, siste gang 14.12.2018 -->
<nav>
  <a class="bilde" href="../../default.php">
    <img class="logo-navHeaderForsiden" src="../img/logo.png" alt="Logoen til USN" width="84" height="42">
  </a>
  <a href="../anonser/anonser.php">Annonser</a>
  <a href="../sosialt/sosialt.php">Events</a>
  <a href="../nyheter/nyheter.php">IT nyheter</a>
  <a href="../personer/personer.php">Søk Interesser</a>
  <a href="../min_profil/min_profil.php">Min Profil</a>
  <a href="../profil/profil.php">Instillinger</a>
  <div class="Loggin">
    <form action="../includes/loggut.inc.php" method="POST">
    <button type="submit" name="submit">Logout</button>
    </form>
  </div>
</nav>

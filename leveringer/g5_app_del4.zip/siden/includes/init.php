<?php
    $salt = "IT2_2019";
    $dbBrukernavn = "alumni_05";
    $dbPassord = "alumni";
    // Connection til database paa skoleserver
    $dsn = "mysql:host=158.36.139.21;dbname=alumni05";
    // Connection til localhost
    //$dsn = "mysql:host=localhost;dbname=alumni05";
?>

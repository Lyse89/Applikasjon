function søkePersoner(søkPerson) {

}

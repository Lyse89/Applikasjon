<?php
    $salt = "IT2_2019";
    $dbBrukernavn = "alumni_05";
    $dbPassord = "alumni";
?>
